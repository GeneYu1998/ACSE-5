#include <iostream>
#include <math.h>
#include <ctime>

using namespace std;

// Super simple function
void doSomething(int input, double other_input)
{
   cout << "Hello!";
   // What happens if I don't call delete on this before exiting??
   // This is stored on the heap
   int *int_array = new int[input];
   
   // Return to the functino
   return;

   // This will never be reached
   delete[] int_array;
}

int main()
{

   // We know these are stored on the stack
   int value = 5;
   double other_value = 10.96;
   // This is stored on the stack as we know how big it is at compile time!
   double temp_array[4] = {1, 6, 7, 9};

   // Call our simple function
   doSomething(value, other_value);

   // Is this stored on the stack or or the heap?
   // Separate question: Is the pointer stored on the stack?
   double *temp_ptr = new double[25];
   delete[] temp_ptr;

   // How much stack memory has been used when we call each (including main) of these functions?

   system("pause");

}