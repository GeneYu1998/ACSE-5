#include <iostream>
#include <math.h>
#include <ctime>
#include <memory>

using namespace std;

int main()
{

   // We know these are stored on the stack
   int *ptr = new int;
   *ptr = 10;
   int *ref = ptr;
   delete ptr;

   // After this delete, the pointer ref is now garbage and 
   // points to undefined values, but we have no way of knowing this

   // Let's make a shared pointer
   std::shared_ptr<int> sptr;

   // takes ownership of pointer - NOTE THIS IS NOT AN ARRAY
   sptr.reset(new int);
   *sptr = 10;     
   cout << "Number of references: " << sptr.use_count() << endl;

   // get weak pointer to data, this won't take ownership
   std::weak_ptr<int> weak1 = sptr;    
   // The reference count here hasn't changed
   cout << "Number of references: " << sptr.use_count() << endl;

   // deletes managed object, and replaces it with a new pointer
   sptr.reset(new int);
   *sptr = 5;    

   // get pointer to new data without taking ownership
   std::weak_ptr<int> weak2 = sptr;

   // we can explicitly test if weak1 still points to something 
   // that is "alive"
   // The lock function returns a shared pointer to the original data
   // But because this is defined in the brackes of the if statemnet
   // It is only alive in the scope of our if statement
   if(auto tmp = weak1.lock())
   {
      std::cout << *tmp << '\n';
   }
   else
   {
      std::cout << "weak1 is expired\n";    
   }

   if(auto tmp = weak2.lock())
   {
      // The reference count here should have changed
      cout << "Number of references: " << sptr.use_count() << endl;
      std::cout << *tmp << '\n';
   }
   else
   {
      std::cout << "weak2 is expired\n";    
   }    
   // But now we should be able to see the shared_ptr returned by lock()
   // has died by now
   cout << "Number of references: " << sptr.use_count() << endl;

   // If we did something like this
   auto tmp_keep_alive = weak2.lock();
   // Then we are keeping the object weak2 points to alive 
   // until tmp_keep_alive goes out of scope and dies
   // The reference count here has changed
   cout << "Number of references: " << sptr.use_count() << endl;   

   system("pause");

}