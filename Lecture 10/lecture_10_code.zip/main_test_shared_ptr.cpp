#include <iostream>
#include <math.h>
#include <ctime>
#include <memory>

using namespace std;

// Super simple function that leaks memory
void doSomething(int input, double other_input)
{
   cout << "Hello!";
   // What happens if I don't call delete on this before exiting??
   // This is stored on the heap
   int *int_array = new int[input];
   
   // Return to the function - Memory leak on int_arrays
   return;
}

// function that calls the delete [] on received pointer
void deleter(int * x)
{
	delete[] x;
}

// Super simple function that doesn't leaks memory
void doSomethingSharedPtr(int input, double other_input)
{
   cout << "Hello!";
   // In C++17 as long as we tell the pointer it is storing an 
   // array it will call the correct destructor
   shared_ptr<int[]> int_array_four(new int[input]);
   // Need the C++17 standard to use the [] access notation on an array
   // in a shared pointer
   //int_array_four[1] = 5;
   // Can't do pointer arithmetic, but we can dereference to get a pointer to the object
   // This will only set the thing in the first memory slot
   //*int_array_four = 1;
   // We can't do this! So arrays are a slightly special case, as with dereferencing
   // we often want to use pointer arithmetic to get us the next thing in memory in an 
   // array
   //*(int_array_four + 1) = 2;

   // Before C++17, the syntax was a little different for a shared pointer
   // if we are storing an array
   // We have to give it a "custom destructor" that explicitly calls delete[]
   // This can still be a useful thing if we want to call some special 
   // destructor when this shared_ptr is destroyed
   shared_ptr<int> int_array_three(new int[input], deleter);
   // We are using the C++11 lambda expressions here
   shared_ptr<int> int_array_two(new int[input], [](int * x){delete[] x;});
   cout << "Number of references: " << int_array_two.use_count() << endl;

   // Now to create a new shared pointer that increments the reference 
   // on a previous shared pointer, happily the = operator is overriden
   // We can of course explicitly use auto syntax from C++11 here too
   auto int_array_extra = int_array_two;
   cout << "Number of references: " << int_array_two.use_count() << endl;
   cout << "Number of references: " << int_array_extra.use_count() << endl;

   // Now if we want access to the array inside the smart pointer, 
   // we are going to have to call .get() and then use the array referencing
   // with that - we also can't use pointer arithmetic
   (int_array_extra.get())[1] = 4;
   
   // Return to the function - don't have to worry about deleting int_array!
   return;
}

// Super simple function that doesn't leaks memory
void doSomethingSharedPtrCrash(int input, double other_input)
{
   cout << "Hello!";

   int *raw_ptr = new int[input];

   // We can explicitly feed it the raw_ptr
   shared_ptr<int> int_array_three(raw_ptr, deleter);
   cout << "Number of references: " << int_array_three.use_count() << endl;

   // Instead of copying the shared_ptr int_array_three, we give it the
   // original raw_ptr
   shared_ptr<int> int_array_extra(raw_ptr, deleter);
   cout << "Number of references: " << int_array_three.use_count() << endl;
   cout << "Number of references: " << int_array_extra.use_count() << endl;   
   
   // Return to the function - Now this should crash when we exit the 
   // function, as int_array_extra and int_array_three had no way to know
   // they were pointing at the same thing
   return;
}

// This will increment the reference counter inside the function due to being
// passed by copy
void testSharedFunc(shared_ptr<int> sp) {
   cout << "Number of references inside: " << sp.use_count() << endl;   
}

// Passing the shared pointer in by reference means 
// this will not increment the reference counter inside the function
// the object our shared pointer refers to may be deleted mid way through
// our function, just like a raw pointer
void testSharedFuncRef(const shared_ptr<int> &sp) {
   cout << "Number of references inside ref: " << sp.use_count() << endl;   
}

int main()
{

   // We know these are stored on the stack
   int value = 5;
   double other_value = 10.96;

   // This will leak memory
   doSomething(value, other_value);
   // This will not leak memory
   doSomethingSharedPtr(value, other_value);        
   // This will not leak memory but it should crash
   //doSomethingSharedPtrCrash(value, other_value);   

   // Let's create a shared pointer
   shared_ptr<int> input(new int[value], deleter); 
   testSharedFunc(input);
   testSharedFuncRef(input);

   system("pause");

}