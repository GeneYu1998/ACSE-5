#include <iostream>
#include <math.h>
#include <ctime>
#include <memory>
#include <vector>

using namespace std;

// function that calls the delete [] on received pointer
void deleter(double * x)
{
	delete[] x;
}

int main()
{
   // Create a number of partitions to represent a function on
   // This must be a power of 2
   int no_partitions = 16;

   // Work out what the power of 2 this is
   int no_levels = 1;
   int partitions_this_level = no_partitions;
   while (partitions_this_level != 1) 
   {
      no_levels++;
      partitions_this_level /= 2;
   }

   // Print out the number of levels we have
   cout << "Number of partitions: " << no_partitions << " Number of levels: " << no_levels << endl;

   // Let's build a vector to store our shared pointers
   vector<shared_ptr<double>> level_data;
   // We know how big we want our vector to be in advance
   level_data.reserve(no_levels);

   for (int level = 0; level < no_levels; level++)
   {
      // Build a new array of size 2^level
      // And store it as a unique pointer
      // Don't have to worry about deleting this!
      // Smart pointers are so convenient      
      // Could we have used a unique_ptr here?
      shared_ptr<double> this_level_data(new double[int(pow(2, level))], deleter);

      // Now push that pointer onto our vector
      level_data.push_back(this_level_data);
   }

   // Let's go and set the value of our P0 function on the finest level
   // Lets just set each partition to have the value of x*2 * exp(-x), where 
   // x is the real line between 0 and 1, and we'll make the x value
   // in each partition at the half way point

   // Just get a raw pointer to the data on our finest level
   double *data_fine = (level_data[no_levels-1]).get();
   // Loop over the number of partitions on that level
   for (int i = 0; i < no_partitions; i++)
   {
      // This is the half way point of our partition
      double x = 0.5 + i;
      // Set the value
      data_fine[i] = pow(x, 2) * exp(-x);
      cout << "Level: " << no_levels << " Partition: " << i << " has centre x position: " << x << " and value: " << data_fine[i] << endl;
   }

   // Now we need to transfer these values onto the coarser P0 grid
   // Start on the finest grid
   for (int level = no_levels - 1; level > 0; level--)
   {
      // Let's get raw pointers to our data arrays on each level
      data_fine = (level_data[level]).get();
      double *data_coarse = (level_data[level-1]).get();
      
      cout << "Level: " << level << " has partitions: " << pow(2, level-1) << endl;
      // Let's loop over the partitions on the coarse grid
      for (int i = 0; i < pow(2, level-1); i++)
      {      
         data_coarse[i] = (data_fine[i*2] + data_fine[i*2 + 1])/2.0;
         cout << "Level: " << level << " Partition: " << i <<  " and value: " << data_coarse[i] << endl;
      }
   }

   // Let's build some memory to store our resulting wavelet coefficients
   shared_ptr<double> wavelet_coefficients(new double[int(pow(2, no_levels-1))], deleter);
   // We know the first function is the scaling function
   // And it just takes the value on our coarsest partition (which should be the average
   // value across the domain)
   (wavelet_coefficients.get())[0] = ((level_data[0]).get())[0];
   // Now let's compute our wavelet coefficients
   // Start from the second coarsest level
   int coefficient_counter = 1;
   for (int level = 1; level < no_levels; level++)
   {
      // Get a raw pointer to the data on this level
      data_fine = (level_data[level]).get();

      // Loop over the number of partitions on the coarser level
      for (int i = 0; i < pow(2, level-1); i++)
      { 
         (wavelet_coefficients.get())[coefficient_counter] = data_fine[i*2] - data_fine[i*2 + 1];
         coefficient_counter++;
      }      
   }

   // Let's print out our wavelet coefficients
   for (int i = 0; i < no_partitions; i++)
   {
      cout << "Wavelet coefficient i: " << i << " has value: " << (wavelet_coefficients.get())[i] << endl;
   }

   // Clear our vector - This should automatically call the 
   // destructor on each of our shared pointers
   level_data.clear();
}